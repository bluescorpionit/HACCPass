# Blue HACCP

Starter Flutter locale-only per smartphone e tablet.

## Caratteristiche già incluse

- Dashboard responsive per smartphone/tablet
- Database SQLite locale
- Controllo temperature
- Creazione automatica di una non conformità se la temperatura è fuori soglia
- Piano pulizie con conferma attività
- Gestione lotti di produzione
- Anteprima etichetta lotto
- Gestione non conformità
- Impostazioni azienda
- Astrazione `PrinterService` pronta per collegare una stampante Bluetooth
- Dati demo iniziali

## Nessun server

Tutti i dati restano nel database SQLite del dispositivo.

## Avvio

Questa cartella contiene il codice applicativo. Se la tua installazione Flutter non trova ancora
le cartelle native Android/iOS, esegui una sola volta dalla cartella del progetto:

```bash
flutter create --platforms=android,ios .
flutter pub get
flutter run
```

Su Windows:

```bat
setup_project.bat
```

Su macOS/Linux:

```bash
chmod +x setup_project.sh
./setup_project.sh
```

## Struttura

- `lib/core/database` database SQLite
- `lib/core/theme` tema grafico
- `lib/models` modelli
- `lib/repositories` accesso ai dati
- `lib/services` servizi, incluso il layer stampante
- `lib/screens` schermate
- `lib/widgets` componenti grafici

## Stampante Bluetooth

Per ora `DemoPrinterService` simula la stampa e mantiene separata la UI dalla tecnologia
della stampante.

Quando scegliamo il modello reale, implementiamo:

```dart
class BluetoothPrinterService implements PrinterService
```

e traduciamo `LabelData` in TSPL, ZPL, CPCL oppure ESC/POS a seconda della stampante.

Questa scelta evita di legare il progetto a un modello hardware prima di averlo deciso.

## Prossimi passi consigliati

1. Anagrafica attrezzature/frigoriferi configurabile.
2. Ingredienti e associazione lotto materia prima -> lotto produzione.
3. Scadenze e notifiche locali.
4. Fornitori e merce in entrata.
5. Allergeni.
6. Pest control.
7. Archivio documentale locale.
8. Esportazione dossier HACCP in PDF.
9. Backup/ripristino locale.
10. Driver stampante Bluetooth reale.
