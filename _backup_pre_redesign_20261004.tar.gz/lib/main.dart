import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'core/database/app_database.dart';
import 'core/theme/app_theme.dart';
import 'repositories/haccp_repository.dart';
import 'screens/app_shell.dart';
import 'services/printer_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('it_IT');
  final database = AppDatabase();
  await database.initialize();

  runApp(
    BlueHaccpApp(
      repository: HaccpRepository(database),
      printerService: DemoPrinterService(),
    ),
  );
}

class BlueHaccpApp extends StatelessWidget {
  const BlueHaccpApp({
    super.key,
    required this.repository,
    required this.printerService,
  });

  final HaccpRepository repository;
  final PrinterService printerService;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Blue HACCP',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: AppShell(
        repository: repository,
        printerService: printerService,
      ),
    );
  }
}
