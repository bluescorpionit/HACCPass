import 'dart:async';
import '../models/haccp_models.dart';

class LabelData {
  const LabelData({
    required this.companyName,
    required this.lot,
    required this.copies,
  });

  final String companyName;
  final ProductionLot lot;
  final int copies;
}

abstract class PrinterService {
  Future<bool> isAvailable();
  Future<void> printLotLabel(LabelData data);
}

class DemoPrinterService implements PrinterService {
  @override
  Future<bool> isAvailable() async => true;

  @override
  Future<void> printLotLabel(LabelData data) async {
    await Future<void>.delayed(const Duration(milliseconds: 650));
  }
}
