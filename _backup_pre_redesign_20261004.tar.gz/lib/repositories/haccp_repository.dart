import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';
import '../core/database/app_database.dart';
import '../models/haccp_models.dart';

class HaccpRepository {
  HaccpRepository(this.database);

  final AppDatabase database;

  Future<List<Equipment>> getEquipment() async {
    final rows = await database.db.query(
      'equipment',
      where: 'active = 1',
      orderBy: 'name',
    );
    return rows.map(Equipment.fromMap).toList();
  }

  Future<Map<String, Object?>> saveTemperature({
    required Equipment equipment,
    required double temperature,
    required String operatorName,
    String? note,
  }) async {
    final compliant =
        temperature >= equipment.minTemp && temperature <= equipment.maxTemp;
    final now = DateTime.now();

    final logId = await database.db.insert('temperature_logs', {
      'equipment_id': equipment.id,
      'temperature': temperature,
      'measured_at': now.toIso8601String(),
      'operator_name': operatorName,
      'compliant': compliant ? 1 : 0,
      'note': note,
    });

    int? ncId;
    if (!compliant) {
      ncId = await database.db.insert('non_conformities', {
        'category': 'Temperatura',
        'title': 'Temperatura fuori limite - ${equipment.name}',
        'description':
            'Rilevati ${temperature.toStringAsFixed(1)} °C. Limiti previsti: '
            '${equipment.minTemp.toStringAsFixed(1)} / '
            '${equipment.maxTemp.toStringAsFixed(1)} °C.',
        'corrective_action': null,
        'opened_at': now.toIso8601String(),
        'closed_at': null,
        'status': 'Aperta',
        'operator_name': operatorName,
        'source_type': 'temperature_log',
        'source_id': logId,
      });
    }

    return {
      'compliant': compliant,
      'nonConformityId': ncId,
    };
  }

  Future<List<Map<String, Object?>>> getTodayTemperatureLogs() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 1));

    return database.db.rawQuery('''
      SELECT t.*, e.name AS equipment_name, e.min_temp, e.max_temp
      FROM temperature_logs t
      JOIN equipment e ON e.id = t.equipment_id
      WHERE t.measured_at >= ? AND t.measured_at < ?
      ORDER BY t.measured_at DESC
    ''', [start.toIso8601String(), end.toIso8601String()]);
  }

  Future<List<CleaningTask>> getCleaningTasks() async {
    final rows = await database.db.query(
      'cleaning_tasks',
      where: 'active = 1',
      orderBy: 'area, title',
    );
    return rows.map(CleaningTask.fromMap).toList();
  }

  Future<void> completeCleaningTask(int id) async {
    await database.db.update(
      'cleaning_tasks',
      {'last_completed_at': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  String generateLotCode(String productName) {
    final now = DateTime.now();
    final prefix = productName
        .trim()
        .replaceAll(RegExp(r'[^A-Za-z0-9]'), '')
        .toUpperCase()
        .padRight(3, 'X')
        .substring(0, 3);
    final date = DateFormat('yyMMdd').format(now);
    final time = DateFormat('HHmm').format(now);
    return 'L$date-$prefix-$time';
  }

  Future<int> createLot({
    required String code,
    required String productName,
    required DateTime producedAt,
    required String operatorName,
    DateTime? expiresAt,
    double? quantity,
    String? unit,
    String? storageInfo,
    String? notes,
  }) {
    return database.db.insert('lots', {
      'code': code,
      'product_name': productName,
      'produced_at': producedAt.toIso8601String(),
      'expires_at': expiresAt?.toIso8601String(),
      'quantity': quantity,
      'unit': unit,
      'storage_info': storageInfo,
      'operator_name': operatorName,
      'notes': notes,
    });
  }

  Future<List<ProductionLot>> getLots() async {
    final rows = await database.db.query(
      'lots',
      orderBy: 'produced_at DESC',
    );
    return rows.map(ProductionLot.fromMap).toList();
  }

  Future<List<NonConformity>> getNonConformities() async {
    final rows = await database.db.query(
      'non_conformities',
      orderBy: "CASE status WHEN 'Aperta' THEN 0 ELSE 1 END, opened_at DESC",
    );
    return rows.map(NonConformity.fromMap).toList();
  }

  Future<int> createNonConformity({
    required String category,
    required String title,
    required String description,
    required String operatorName,
    String? correctiveAction,
  }) {
    return database.db.insert('non_conformities', {
      'category': category,
      'title': title,
      'description': description,
      'corrective_action': correctiveAction,
      'opened_at': DateTime.now().toIso8601String(),
      'closed_at': null,
      'status': 'Aperta',
      'operator_name': operatorName,
    });
  }

  Future<void> closeNonConformity({
    required int id,
    required String correctiveAction,
  }) async {
    await database.db.update(
      'non_conformities',
      {
        'status': 'Chiusa',
        'corrective_action': correctiveAction,
        'closed_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<String> getSetting(String key, {String fallback = ''}) async {
    final rows = await database.db.query(
      'settings',
      where: 'key = ?',
      whereArgs: [key],
      limit: 1,
    );
    if (rows.isEmpty) return fallback;
    return (rows.first['value'] as String?) ?? fallback;
  }

  Future<void> setSetting(String key, String value) async {
    await database.db.insert(
      'settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<String, int>> getDashboardCounters() async {
    final cleaning = await getCleaningTasks();
    final openNc = Sqflite.firstIntValue(
          await database.db.rawQuery(
            "SELECT COUNT(*) FROM non_conformities WHERE status = 'Aperta'",
          ),
        ) ??
        0;

    final lots = Sqflite.firstIntValue(
          await database.db.rawQuery('SELECT COUNT(*) FROM lots'),
        ) ??
        0;

    final todayTemps = (await getTodayTemperatureLogs()).length;

    return {
      'temperature': todayTemps,
      'cleaningDone': cleaning.where((e) => e.completedToday).length,
      'cleaningTotal': cleaning.length,
      'openNc': openNc,
      'lots': lots,
    };
  }
}
