class Equipment {
  const Equipment({
    required this.id,
    required this.name,
    required this.type,
    required this.minTemp,
    required this.maxTemp,
  });

  final int id;
  final String name;
  final String type;
  final double minTemp;
  final double maxTemp;

  factory Equipment.fromMap(Map<String, Object?> map) => Equipment(
        id: map['id'] as int,
        name: map['name'] as String,
        type: map['type'] as String,
        minTemp: (map['min_temp'] as num).toDouble(),
        maxTemp: (map['max_temp'] as num).toDouble(),
      );
}

class CleaningTask {
  const CleaningTask({
    required this.id,
    required this.area,
    required this.title,
    required this.frequency,
    this.productName,
    this.lastCompletedAt,
  });

  final int id;
  final String area;
  final String title;
  final String frequency;
  final String? productName;
  final DateTime? lastCompletedAt;

  bool get completedToday {
    final value = lastCompletedAt;
    if (value == null) return false;
    final now = DateTime.now();
    return value.year == now.year &&
        value.month == now.month &&
        value.day == now.day;
  }

  factory CleaningTask.fromMap(Map<String, Object?> map) => CleaningTask(
        id: map['id'] as int,
        area: map['area'] as String,
        title: map['title'] as String,
        frequency: map['frequency'] as String,
        productName: map['product_name'] as String?,
        lastCompletedAt: map['last_completed_at'] == null
            ? null
            : DateTime.parse(map['last_completed_at'] as String),
      );
}

class ProductionLot {
  const ProductionLot({
    required this.id,
    required this.code,
    required this.productName,
    required this.producedAt,
    required this.operatorName,
    this.expiresAt,
    this.quantity,
    this.unit,
    this.storageInfo,
    this.notes,
  });

  final int id;
  final String code;
  final String productName;
  final DateTime producedAt;
  final DateTime? expiresAt;
  final double? quantity;
  final String? unit;
  final String? storageInfo;
  final String operatorName;
  final String? notes;

  factory ProductionLot.fromMap(Map<String, Object?> map) => ProductionLot(
        id: map['id'] as int,
        code: map['code'] as String,
        productName: map['product_name'] as String,
        producedAt: DateTime.parse(map['produced_at'] as String),
        expiresAt: map['expires_at'] == null
            ? null
            : DateTime.parse(map['expires_at'] as String),
        quantity: (map['quantity'] as num?)?.toDouble(),
        unit: map['unit'] as String?,
        storageInfo: map['storage_info'] as String?,
        operatorName: map['operator_name'] as String,
        notes: map['notes'] as String?,
      );
}

class NonConformity {
  const NonConformity({
    required this.id,
    required this.category,
    required this.title,
    required this.description,
    required this.openedAt,
    required this.status,
    required this.operatorName,
    this.correctiveAction,
    this.closedAt,
  });

  final int id;
  final String category;
  final String title;
  final String description;
  final String? correctiveAction;
  final DateTime openedAt;
  final DateTime? closedAt;
  final String status;
  final String operatorName;

  factory NonConformity.fromMap(Map<String, Object?> map) => NonConformity(
        id: map['id'] as int,
        category: map['category'] as String,
        title: map['title'] as String,
        description: map['description'] as String,
        correctiveAction: map['corrective_action'] as String?,
        openedAt: DateTime.parse(map['opened_at'] as String),
        closedAt: map['closed_at'] == null
            ? null
            : DateTime.parse(map['closed_at'] as String),
        status: map['status'] as String,
        operatorName: map['operator_name'] as String,
      );
}
