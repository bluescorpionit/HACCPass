import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  Database? _db;

  Database get db {
    final value = _db;
    if (value == null) {
      throw StateError('Database non inizializzato');
    }
    return value;
  }

  Future<void> initialize() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'blue_haccp.db');

    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE equipment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            min_temp REAL NOT NULL,
            max_temp REAL NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
          )
        ''');

        await database.execute('''
          CREATE TABLE temperature_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id INTEGER NOT NULL,
            temperature REAL NOT NULL,
            measured_at TEXT NOT NULL,
            operator_name TEXT NOT NULL,
            compliant INTEGER NOT NULL,
            note TEXT,
            FOREIGN KEY(equipment_id) REFERENCES equipment(id)
          )
        ''');

        await database.execute('''
          CREATE TABLE cleaning_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            area TEXT NOT NULL,
            title TEXT NOT NULL,
            frequency TEXT NOT NULL,
            product_name TEXT,
            last_completed_at TEXT,
            active INTEGER NOT NULL DEFAULT 1
          )
        ''');

        await database.execute('''
          CREATE TABLE lots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            product_name TEXT NOT NULL,
            produced_at TEXT NOT NULL,
            expires_at TEXT,
            quantity REAL,
            unit TEXT,
            storage_info TEXT,
            operator_name TEXT NOT NULL,
            notes TEXT
          )
        ''');

        await database.execute('''
          CREATE TABLE non_conformities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            corrective_action TEXT,
            opened_at TEXT NOT NULL,
            closed_at TEXT,
            status TEXT NOT NULL,
            operator_name TEXT NOT NULL,
            source_type TEXT,
            source_id INTEGER
          )
        ''');

        await database.execute('''
          CREATE TABLE settings (
            key TEXT PRIMARY KEY,
            value TEXT
          )
        ''');

        await _seed(database);
      },
    );
  }

  Future<void> _seed(Database database) async {
    await database.insert('equipment', {
      'name': 'Frigo cucina',
      'type': 'Frigorifero',
      'min_temp': 0.0,
      'max_temp': 4.0,
      'active': 1,
    });

    await database.insert('equipment', {
      'name': 'Freezer',
      'type': 'Congelatore',
      'min_temp': -24.0,
      'max_temp': -18.0,
      'active': 1,
    });

    await database.insert('equipment', {
      'name': 'Frigo bevande',
      'type': 'Frigorifero',
      'min_temp': 0.0,
      'max_temp': 6.0,
      'active': 1,
    });

    final tasks = [
      {
        'area': 'Cucina',
        'title': 'Piani di lavoro',
        'frequency': 'Dopo ogni utilizzo',
        'product_name': 'Sanificante superfici',
      },
      {
        'area': 'Cucina',
        'title': 'Affettatrice',
        'frequency': 'Giornaliera',
        'product_name': 'Detergente + disinfettante',
      },
      {
        'area': 'Locale',
        'title': 'Pavimenti',
        'frequency': '2 volte al giorno',
        'product_name': 'Detergente pavimenti',
      },
      {
        'area': 'Magazzino',
        'title': 'Scaffalature',
        'frequency': 'Settimanale',
        'product_name': 'Detergente superfici',
      },
    ];

    for (final task in tasks) {
      await database.insert('cleaning_tasks', task);
    }

    await database.insert('settings', {
      'key': 'company_name',
      'value': 'La mia attività',
    });
    await database.insert('settings', {
      'key': 'default_operator',
      'value': 'Operatore',
    });
    await database.insert('settings', {
      'key': 'printer_name',
      'value': 'Stampante etichette demo',
    });
  }
}
