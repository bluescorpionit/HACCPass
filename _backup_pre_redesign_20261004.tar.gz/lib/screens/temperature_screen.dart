import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/theme/app_theme.dart';
import '../models/haccp_models.dart';
import '../repositories/haccp_repository.dart';
import '../widgets/common_widgets.dart';

class TemperatureScreen extends StatefulWidget {
  const TemperatureScreen({super.key, required this.repository});

  final HaccpRepository repository;

  @override
  State<TemperatureScreen> createState() => _TemperatureScreenState();
}

class _TemperatureScreenState extends State<TemperatureScreen> {
  late Future<_TemperatureData> future;

  @override
  void initState() {
    super.initState();
    future = _load();
  }

  Future<_TemperatureData> _load() async {
    return _TemperatureData(
      equipment: await widget.repository.getEquipment(),
      logs: await widget.repository.getTodayTemperatureLogs(),
      operatorName: await widget.repository.getSetting(
        'default_operator',
        fallback: 'Operatore',
      ),
    );
  }

  void _reload() => setState(() => future = _load());

  Future<void> _register(Equipment equipment, String operatorName) async {
    final controller = TextEditingController();
    final noteController = TextEditingController();

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            0,
            20,
            MediaQuery.viewInsetsOf(context).bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                equipment.name,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                'Limiti: ${equipment.minTemp.toStringAsFixed(1)} / '
                '${equipment.maxTemp.toStringAsFixed(1)} °C',
              ),
              const SizedBox(height: 18),
              TextField(
                controller: controller,
                autofocus: true,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true, signed: true),
                decoration: const InputDecoration(
                  labelText: 'Temperatura rilevata',
                  suffixText: '°C',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: noteController,
                decoration: const InputDecoration(
                  labelText: 'Nota (facoltativa)',
                ),
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () async {
                  final value = double.tryParse(
                    controller.text.trim().replaceAll(',', '.'),
                  );
                  if (value == null) return;

                  final result = await widget.repository.saveTemperature(
                    equipment: equipment,
                    temperature: value,
                    operatorName: operatorName,
                    note: noteController.text.trim(),
                  );

                  if (!context.mounted) return;
                  Navigator.pop(context, result['compliant'] as bool);
                },
                icon: const Icon(Icons.save_outlined),
                label: const Text('Salva controllo'),
              ),
            ],
          ),
        );
      },
    );

    if (saved == null || !mounted) return;
    _reload();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          saved
              ? 'Temperatura registrata: conforme.'
              : 'Temperatura fuori limite: creata una non conformità.',
        ),
        backgroundColor: saved ? AppTheme.success : AppTheme.danger,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_TemperatureData>(
      future: future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final data = snapshot.data!;

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle('Temperature'),
            const SizedBox(height: 6),
            const Text(
              'Registra in pochi tocchi i controlli di frigoriferi, freezer e celle.',
              style: TextStyle(color: Color(0xFF667270)),
            ),
            const SizedBox(height: 20),
            ...data.equipment.map(
              (equipment) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 9,
                    ),
                    leading: const CircleAvatar(
                      child: Icon(Icons.ac_unit),
                    ),
                    title: Text(
                      equipment.name,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${equipment.type} • '
                      '${equipment.minTemp.toStringAsFixed(1)} / '
                      '${equipment.maxTemp.toStringAsFixed(1)} °C',
                    ),
                    trailing: FilledButton(
                      onPressed: () =>
                          _register(equipment, data.operatorName),
                      child: const Text('Registra'),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const SectionTitle('Controlli di oggi'),
            const SizedBox(height: 12),
            if (data.logs.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(22),
                  child: Text('Nessuna temperatura registrata oggi.'),
                ),
              )
            else
              ...data.logs.map(
                (log) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor:
                            ((log['compliant'] as int) == 1
                                    ? AppTheme.success
                                    : AppTheme.danger)
                                .withValues(alpha: 0.10),
                        child: Icon(
                          (log['compliant'] as int) == 1
                              ? Icons.check
                              : Icons.priority_high,
                          color: (log['compliant'] as int) == 1
                              ? AppTheme.success
                              : AppTheme.danger,
                        ),
                      ),
                      title: Text(log['equipment_name'] as String),
                      subtitle: Text(
                        DateFormat('HH:mm').format(
                          DateTime.parse(log['measured_at'] as String),
                        ),
                      ),
                      trailing: Text(
                        '${(log['temperature'] as num).toStringAsFixed(1)} °C',
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _TemperatureData {
  const _TemperatureData({
    required this.equipment,
    required this.logs,
    required this.operatorName,
  });

  final List<Equipment> equipment;
  final List<Map<String, Object?>> logs;
  final String operatorName;
}
