import 'package:flutter/material.dart';
import '../repositories/haccp_repository.dart';
import '../services/printer_service.dart';
import 'cleaning_screen.dart';
import 'dashboard_screen.dart';
import 'lots_screen.dart';
import 'non_conformities_screen.dart';
import 'settings_screen.dart';
import 'temperature_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({
    super.key,
    required this.repository,
    required this.printerService,
  });

  final HaccpRepository repository;
  final PrinterService printerService;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      DashboardScreen(
        repository: widget.repository,
        onNavigate: (value) => setState(() => index = value),
      ),
      TemperatureScreen(repository: widget.repository),
      CleaningScreen(repository: widget.repository),
      LotsScreen(
        repository: widget.repository,
        printerService: widget.printerService,
      ),
      NonConformitiesScreen(repository: widget.repository),
      SettingsScreen(repository: widget.repository),
    ];

    final destinations = const [
      NavigationDestination(
        icon: Icon(Icons.home_outlined),
        selectedIcon: Icon(Icons.home),
        label: 'Oggi',
      ),
      NavigationDestination(
        icon: Icon(Icons.thermostat_outlined),
        selectedIcon: Icon(Icons.thermostat),
        label: 'Temperature',
      ),
      NavigationDestination(
        icon: Icon(Icons.cleaning_services_outlined),
        selectedIcon: Icon(Icons.cleaning_services),
        label: 'Pulizie',
      ),
      NavigationDestination(
        icon: Icon(Icons.inventory_2_outlined),
        selectedIcon: Icon(Icons.inventory_2),
        label: 'Lotti',
      ),
      NavigationDestination(
        icon: Icon(Icons.warning_amber_outlined),
        selectedIcon: Icon(Icons.warning_amber),
        label: 'NC',
      ),
      NavigationDestination(
        icon: Icon(Icons.settings_outlined),
        selectedIcon: Icon(Icons.settings),
        label: 'Impostazioni',
      ),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 900;

        if (!wide) {
          return Scaffold(
            body: SafeArea(child: screens[index]),
            bottomNavigationBar: NavigationBar(
              selectedIndex: index,
              onDestinationSelected: (value) => setState(() => index = value),
              destinations: destinations,
            ),
          );
        }

        return Scaffold(
          body: SafeArea(
            child: Row(
              children: [
                NavigationRail(
                  selectedIndex: index,
                  onDestinationSelected: (value) =>
                      setState(() => index = value),
                  labelType: NavigationRailLabelType.all,
                  leading: const Padding(
                    padding: EdgeInsets.only(top: 16, bottom: 24),
                    child: CircleAvatar(
                      radius: 24,
                      child: Icon(Icons.verified_user_outlined),
                    ),
                  ),
                  destinations: destinations
                      .map(
                        (e) => NavigationRailDestination(
                          icon: e.icon,
                          selectedIcon: e.selectedIcon,
                          label: Text(e.label),
                        ),
                      )
                      .toList(),
                ),
                const VerticalDivider(width: 1),
                Expanded(child: screens[index]),
              ],
            ),
          ),
        );
      },
    );
  }
}
