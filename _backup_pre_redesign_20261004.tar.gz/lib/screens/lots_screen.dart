import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/haccp_models.dart';
import '../repositories/haccp_repository.dart';
import '../services/printer_service.dart';
import '../widgets/common_widgets.dart';

class LotsScreen extends StatefulWidget {
  const LotsScreen({
    super.key,
    required this.repository,
    required this.printerService,
  });

  final HaccpRepository repository;
  final PrinterService printerService;

  @override
  State<LotsScreen> createState() => _LotsScreenState();
}

class _LotsScreenState extends State<LotsScreen> {
  late Future<List<ProductionLot>> future;

  @override
  void initState() {
    super.initState();
    future = widget.repository.getLots();
  }

  void _reload() => setState(() => future = widget.repository.getLots());

  Future<void> _newLot() async {
    final productController = TextEditingController();
    final qtyController = TextEditingController();
    final storageController = TextEditingController(text: 'Conservare a 0/+4 °C');
    final notesController = TextEditingController();
    final operator = await widget.repository.getSetting(
      'default_operator',
      fallback: 'Operatore',
    );

    if (!mounted) return;

    DateTime producedAt = DateTime.now();
    DateTime expiresAt = DateTime.now().add(const Duration(days: 2));

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(
                20,
                0,
                20,
                MediaQuery.viewInsetsOf(context).bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Nuovo lotto',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                    ),
                    const SizedBox(height: 18),
                    TextField(
                      controller: productController,
                      decoration: const InputDecoration(
                        labelText: 'Prodotto',
                        hintText: 'Es. Lasagna Bolognese',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: qtyController,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Quantità',
                        suffixText: 'pz',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: storageController,
                      decoration: const InputDecoration(
                        labelText: 'Conservazione',
                      ),
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Data produzione'),
                      subtitle:
                          Text(DateFormat('dd/MM/yyyy HH:mm').format(producedAt)),
                      trailing: const Icon(Icons.calendar_month),
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Utilizzare entro'),
                      subtitle:
                          Text(DateFormat('dd/MM/yyyy').format(expiresAt)),
                      trailing: IconButton(
                        icon: const Icon(Icons.edit_calendar),
                        onPressed: () async {
                          final selected = await showDatePicker(
                            context: context,
                            firstDate: DateTime.now(),
                            lastDate:
                                DateTime.now().add(const Duration(days: 3650)),
                            initialDate: expiresAt,
                          );
                          if (selected != null) {
                            setLocalState(() => expiresAt = selected);
                          }
                        },
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: notesController,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: 'Note',
                      ),
                    ),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                      onPressed: () async {
                        final product = productController.text.trim();
                        if (product.isEmpty) return;

                        final code =
                            widget.repository.generateLotCode(product);

                        await widget.repository.createLot(
                          code: code,
                          productName: product,
                          producedAt: producedAt,
                          expiresAt: expiresAt,
                          quantity: double.tryParse(
                            qtyController.text.replaceAll(',', '.'),
                          ),
                          unit: 'pz',
                          storageInfo: storageController.text.trim(),
                          operatorName: operator,
                          notes: notesController.text.trim(),
                        );

                        if (!context.mounted) return;
                        Navigator.pop(context, true);
                      },
                      icon: const Icon(Icons.add_box_outlined),
                      label: const Text('Crea lotto'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    if (saved == true) _reload();
  }

  Future<void> _showLabel(ProductionLot lot) async {
    int copies = 1;
    final company = await widget.repository.getSetting(
      'company_name',
      fallback: 'La mia attività',
    );

    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            return AlertDialog(
              title: const Text('Anteprima etichetta'),
              content: SizedBox(
                width: 360,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.black26),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            company.toUpperCase(),
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            lot.productName,
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 20,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text('LOTTO  ${lot.code}'),
                          Text(
                            'Prodotto: ${DateFormat('dd/MM/yyyy HH:mm').format(lot.producedAt)}',
                          ),
                          if (lot.expiresAt != null)
                            Text(
                              'Utilizzare entro: ${DateFormat('dd/MM/yyyy').format(lot.expiresAt!)}',
                            ),
                          if (lot.storageInfo?.isNotEmpty == true)
                            Text(lot.storageInfo!),
                          const SizedBox(height: 10),
                          Container(
                            height: 36,
                            alignment: Alignment.center,
                            color: Colors.black,
                            child: Text(
                              lot.code.replaceAll('-', ''),
                              style: const TextStyle(
                                color: Colors.white,
                                letterSpacing: 3,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton.filledTonal(
                          onPressed: copies > 1
                              ? () => setLocalState(() => copies--)
                              : null,
                          icon: const Icon(Icons.remove),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18),
                          child: Text(
                            '$copies copie',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        IconButton.filledTonal(
                          onPressed: () => setLocalState(() => copies++),
                          icon: const Icon(Icons.add),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Chiudi'),
                ),
                FilledButton.icon(
                  onPressed: () async {
                    await widget.printerService.printLotLabel(
                      LabelData(
                        companyName: company,
                        lot: lot,
                        copies: copies,
                      ),
                    );
                    if (!context.mounted) return;
                    Navigator.pop(context);
                    ScaffoldMessenger.of(this.context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Stampa demo completata. Driver Bluetooth da collegare al modello scelto.',
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.print),
                  label: const Text('Stampa'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<ProductionLot>>(
      future: future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final lots = snapshot.data!;

        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _newLot,
            icon: const Icon(Icons.add),
            label: const Text('Nuovo lotto'),
          ),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const SectionTitle('Lotti e produzione'),
              const SizedBox(height: 6),
              const Text(
                'Crea il lotto, conserva i dati sul dispositivo e prepara l’etichetta.',
                style: TextStyle(color: Color(0xFF667270)),
              ),
              const SizedBox(height: 20),
              if (lots.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(22),
                    child: Text('Nessun lotto creato.'),
                  ),
                )
              else
                ...lots.map(
                  (lot) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 10,
                        ),
                        leading: const CircleAvatar(
                          child: Icon(Icons.inventory_2_outlined),
                        ),
                        title: Text(
                          lot.productName,
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text(
                          '${lot.code}\n'
                          '${DateFormat('dd/MM/yyyy HH:mm').format(lot.producedAt)}',
                        ),
                        isThreeLine: true,
                        trailing: IconButton.filledTonal(
                          onPressed: () => _showLabel(lot),
                          icon: const Icon(Icons.print_outlined),
                          tooltip: 'Etichetta',
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
