import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import '../repositories/haccp_repository.dart';
import '../widgets/common_widgets.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.repository,
    required this.onNavigate,
  });

  final HaccpRepository repository;
  final ValueChanged<int> onNavigate;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Future<_DashboardData>? future;

  @override
  void initState() {
    super.initState();
    initializeDateFormatting('it_IT');
    future = _load();
  }

  Future<_DashboardData> _load() async {
    final company =
        await widget.repository.getSetting('company_name', fallback: 'Attività');
    final counters = await widget.repository.getDashboardCounters();
    final logs = await widget.repository.getTodayTemperatureLogs();
    final cleaning = await widget.repository.getCleaningTasks();
    return _DashboardData(
      company: company,
      counters: counters,
      recentTemperatures: logs.take(3).toList(),
      cleaning: cleaning,
    );
  }

  Future<void> _refresh() async {
    setState(() => future = _load());
    await future;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_DashboardData>(
      future: future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final data = snapshot.data!;
        final counters = data.counters;
        final total = counters['cleaningTotal'] ?? 0;
        final done = counters['cleaningDone'] ?? 0;
        final percent = total == 0 ? 100 : ((done / total) * 100).round();

        return RefreshIndicator(
          onRefresh: _refresh,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(
                'Blue HACCP',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 5),
              Text(
                'Buongiorno, ${data.company}',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                DateFormat('EEEE d MMMM', 'it_IT').format(DateTime.now()),
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: const Color(0xFF667270),
                    ),
              ),
              const SizedBox(height: 22),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 72,
                        height: 72,
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            CircularProgressIndicator(
                              value: percent / 100,
                              strokeWidth: 8,
                              backgroundColor: const Color(0xFFE5ECEB),
                            ),
                            Center(
                              child: Text(
                                '$percent%',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 18),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Controlli di oggi',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge
                                  ?.copyWith(fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '$done attività completate su $total programmate.',
                              style: const TextStyle(
                                color: Color(0xFF667270),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              GridView.count(
                crossAxisCount:
                    MediaQuery.sizeOf(context).width >= 700 ? 4 : 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.35,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  MetricCard(
                    icon: Icons.thermostat,
                    value: '${counters['temperature'] ?? 0}',
                    label: 'Temperature',
                    onTap: () => widget.onNavigate(1),
                  ),
                  MetricCard(
                    icon: Icons.cleaning_services,
                    value: '$done/$total',
                    label: 'Pulizie',
                    onTap: () => widget.onNavigate(2),
                  ),
                  MetricCard(
                    icon: Icons.inventory_2,
                    value: '${counters['lots'] ?? 0}',
                    label: 'Lotti',
                    onTap: () => widget.onNavigate(3),
                  ),
                  MetricCard(
                    icon: Icons.warning_amber,
                    value: '${counters['openNc'] ?? 0}',
                    label: 'NC aperte',
                    alert: (counters['openNc'] ?? 0) > 0,
                    onTap: () => widget.onNavigate(4),
                  ),
                ],
              ),
              const SizedBox(height: 26),
              const SectionTitle('Attività rapide'),
              const SizedBox(height: 12),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.thermostat),
                      ),
                      title: const Text('Registra temperatura'),
                      subtitle: const Text('Frigo, freezer e celle'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => widget.onNavigate(1),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.inventory_2_outlined),
                      ),
                      title: const Text('Crea lotto'),
                      subtitle: const Text('Produzione ed etichetta'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => widget.onNavigate(3),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.warning_amber_outlined),
                      ),
                      title: const Text('Apri non conformità'),
                      subtitle: const Text('Registra problema e azione'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => widget.onNavigate(4),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _DashboardData {
  const _DashboardData({
    required this.company,
    required this.counters,
    required this.recentTemperatures,
    required this.cleaning,
  });

  final String company;
  final Map<String, int> counters;
  final List<Map<String, Object?>> recentTemperatures;
  final List<dynamic> cleaning;
}
