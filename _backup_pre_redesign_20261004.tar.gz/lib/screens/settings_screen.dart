import 'package:flutter/material.dart';
import '../repositories/haccp_repository.dart';
import '../widgets/common_widgets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.repository});

  final HaccpRepository repository;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final companyController = TextEditingController();
  final operatorController = TextEditingController();
  final printerController = TextEditingController();
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    companyController.text = await widget.repository.getSetting(
      'company_name',
      fallback: 'La mia attività',
    );
    operatorController.text = await widget.repository.getSetting(
      'default_operator',
      fallback: 'Operatore',
    );
    printerController.text = await widget.repository.getSetting(
      'printer_name',
      fallback: 'Stampante etichette demo',
    );
    if (mounted) setState(() => loaded = true);
  }

  Future<void> _save() async {
    await widget.repository
        .setSetting('company_name', companyController.text.trim());
    await widget.repository
        .setSetting('default_operator', operatorController.text.trim());
    await widget.repository
        .setSetting('printer_name', printerController.text.trim());

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Impostazioni salvate in locale.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SectionTitle('Impostazioni'),
        const SizedBox(height: 6),
        const Text(
          'Tutto resta sul dispositivo. Nessun server e nessun account cloud.',
          style: TextStyle(color: Color(0xFF667270)),
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                TextField(
                  controller: companyController,
                  decoration: const InputDecoration(
                    labelText: 'Ragione sociale / nome attività',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: operatorController,
                  decoration: const InputDecoration(
                    labelText: 'Operatore predefinito',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: printerController,
                  decoration: const InputDecoration(
                    labelText: 'Nome stampante',
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _save,
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('Salva impostazioni'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Archivio locale',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Il database SQLite contiene temperature, pulizie, lotti, '
                  'non conformità e configurazione. Backup ed esportazione '
                  'verranno aggiunti nel prossimo step.',
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
