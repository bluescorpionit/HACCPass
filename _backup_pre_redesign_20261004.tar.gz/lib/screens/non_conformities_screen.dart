import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/haccp_models.dart';
import '../repositories/haccp_repository.dart';
import '../widgets/common_widgets.dart';

class NonConformitiesScreen extends StatefulWidget {
  const NonConformitiesScreen({super.key, required this.repository});

  final HaccpRepository repository;

  @override
  State<NonConformitiesScreen> createState() => _NonConformitiesScreenState();
}

class _NonConformitiesScreenState extends State<NonConformitiesScreen> {
  late Future<List<NonConformity>> future;

  @override
  void initState() {
    super.initState();
    future = widget.repository.getNonConformities();
  }

  void _reload() =>
      setState(() => future = widget.repository.getNonConformities());

  Future<void> _newNc() async {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    final actionController = TextEditingController();
    String category = 'Altro';
    final operator = await widget.repository.getSetting(
      'default_operator',
      fallback: 'Operatore',
    );

    if (!mounted) return;

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(
                20,
                0,
                20,
                MediaQuery.viewInsetsOf(context).bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Nuova non conformità',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                    ),
                    const SizedBox(height: 18),
                    DropdownButtonFormField<String>(
                      initialValue: category,
                      decoration: const InputDecoration(labelText: 'Categoria'),
                      items: const [
                        'Temperatura',
                        'Materia prima',
                        'Pulizia',
                        'Infestanti',
                        'Attrezzatura',
                        'Scadenza',
                        'Etichettatura',
                        'Altro',
                      ]
                          .map(
                            (value) => DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setLocalState(() => category = value);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: titleController,
                      decoration:
                          const InputDecoration(labelText: 'Titolo / problema'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: descriptionController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Descrizione',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: actionController,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: 'Azione immediata (facoltativa)',
                      ),
                    ),
                    const SizedBox(height: 18),
                    FilledButton(
                      onPressed: () async {
                        if (titleController.text.trim().isEmpty ||
                            descriptionController.text.trim().isEmpty) {
                          return;
                        }

                        await widget.repository.createNonConformity(
                          category: category,
                          title: titleController.text.trim(),
                          description: descriptionController.text.trim(),
                          correctiveAction: actionController.text.trim(),
                          operatorName: operator,
                        );

                        if (!context.mounted) return;
                        Navigator.pop(context, true);
                      },
                      child: const Text('Apri non conformità'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    if (saved == true) _reload();
  }

  Future<void> _close(NonConformity nc) async {
    final controller =
        TextEditingController(text: nc.correctiveAction ?? '');

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Chiudi non conformità'),
        content: TextField(
          controller: controller,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Azione correttiva / risoluzione',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annulla'),
          ),
          FilledButton(
            onPressed: () async {
              if (controller.text.trim().isEmpty) return;
              await widget.repository.closeNonConformity(
                id: nc.id,
                correctiveAction: controller.text.trim(),
              );
              if (!context.mounted) return;
              Navigator.pop(context, true);
            },
            child: const Text('Chiudi'),
          ),
        ],
      ),
    );

    if (saved == true) _reload();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<NonConformity>>(
      future: future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final items = snapshot.data!;

        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _newNc,
            icon: const Icon(Icons.add),
            label: const Text('Nuova NC'),
          ),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const SectionTitle('Non conformità'),
              const SizedBox(height: 6),
              const Text(
                'Problema, azione correttiva, operatore e stato restano nello storico locale.',
                style: TextStyle(color: Color(0xFF667270)),
              ),
              const SizedBox(height: 20),
              if (items.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(22),
                    child: Text('Nessuna non conformità registrata.'),
                  ),
                )
              else
                ...items.map(
                  (nc) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    nc.title,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontSize: 17,
                                    ),
                                  ),
                                ),
                                StatusPill(
                                  text: nc.status.toUpperCase(),
                                  type: nc.status == 'Aperta'
                                      ? StatusType.danger
                                      : StatusType.success,
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '${nc.category} • '
                              '${DateFormat('dd/MM/yyyy HH:mm').format(nc.openedAt)}',
                              style: const TextStyle(
                                color: Color(0xFF667270),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(nc.description),
                            if (nc.correctiveAction?.isNotEmpty == true) ...[
                              const SizedBox(height: 10),
                              Text(
                                'Azione: ${nc.correctiveAction}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                            if (nc.status == 'Aperta') ...[
                              const SizedBox(height: 14),
                              Align(
                                alignment: Alignment.centerRight,
                                child: FilledButton.tonal(
                                  onPressed: () => _close(nc),
                                  child: const Text('Risolvi e chiudi'),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
