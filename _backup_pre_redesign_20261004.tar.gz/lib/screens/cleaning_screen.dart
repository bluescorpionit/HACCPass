import 'package:flutter/material.dart';
import '../models/haccp_models.dart';
import '../repositories/haccp_repository.dart';
import '../widgets/common_widgets.dart';

class CleaningScreen extends StatefulWidget {
  const CleaningScreen({super.key, required this.repository});

  final HaccpRepository repository;

  @override
  State<CleaningScreen> createState() => _CleaningScreenState();
}

class _CleaningScreenState extends State<CleaningScreen> {
  late Future<List<CleaningTask>> future;

  @override
  void initState() {
    super.initState();
    future = widget.repository.getCleaningTasks();
  }

  void _reload() =>
      setState(() => future = widget.repository.getCleaningTasks());

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<CleaningTask>>(
      future: future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final tasks = snapshot.data!;

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SectionTitle('Pulizie e sanificazione'),
            const SizedBox(height: 6),
            const Text(
              'Le frequenze sono configurabili e ogni attività viene registrata localmente.',
              style: TextStyle(color: Color(0xFF667270)),
            ),
            const SizedBox(height: 20),
            ...tasks.map(
              (task) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 10,
                    ),
                    leading: CircleAvatar(
                      child: Icon(
                        task.completedToday
                            ? Icons.check
                            : Icons.cleaning_services_outlined,
                      ),
                    ),
                    title: Text(
                      task.title,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${task.area} • ${task.frequency}'
                      '${task.productName == null ? '' : '\n${task.productName}'}',
                    ),
                    isThreeLine: task.productName != null,
                    trailing: task.completedToday
                        ? const StatusPill(
                            text: 'FATTO',
                            type: StatusType.success,
                          )
                        : FilledButton(
                            onPressed: () async {
                              await widget.repository
                                  .completeCleaningTask(task.id);
                              _reload();
                            },
                            child: const Text('Conferma'),
                          ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
